//
//  Attribute.h
//
//  Created by apple on 12-11-30.
//  Copyright (c) 2012年 apple. All rights reserved.
//

#ifndef Collector_HealthAttribute_h
#define Collector_HealthAttribute_h

// For Sanmeditech
#define SANMEDITECH_SERVICE_UUID                0xFFB0
#define SANMEDITECH_FEATURE_CHARACTER           0xFFB2
#define SANMEDITECH_FACTORY_INFO_CHARACTER      0xFFB5

#define SANMEDITECH_RECONNECT_POSITIVE_FLAG     0x0
#define SANMEDITECH_RECONNECT_NAGETIVE_FLAG     0x03

#endif


#define kSDCurrentMemberKey  @"kSDCurrentMemberKey"
